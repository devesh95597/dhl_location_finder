<?php

namespace Drupal\dhl_location_finder\Controller;

use \Drupal\Core\Controller\ControllerBase;
use GuzzleHttp\Client;
use Symfony\Component\Yaml\Yaml;
use GuzzleHttp\Exception\ClientException;


class LocationSearchController extends ControllerBase
{
    public function index()
    {
    $data =  $this->getLocation();  // Get the search filter data  
    $yaml = Yaml::dump($data, 3);  // Convert search data to yaml formate 
    $form = \Drupal::formBuilder()->getForm('\Drupal\dhl_location_finder\Form\LocationForm'); // rendering the search form in twig template
     return [
        '#theme' => 'location_search',
        '#attached' => [
          'library' => [
            'dhl_location_finder/dhl_location_finder_library',
          ],			
          ],
        '#form' =>  $form,
        '#yaml' => $yaml,
        '#cache' => [
          'max-age' => 0,
        ],
        ];
    }

    public function getLocation()
    {    
    try {
        $country_code = \Drupal::request()->get('countryCode'); // geting countryCode in query parameter
        $city = \Drupal::request()->get('addressLocality'); // geting city in query parameter
        $postal_code = \Drupal::request()->get('postalCode'); // geting postalcode in query parameter   
        if($country_code && trim($country_code) != '')
        {
        $client = new Client();  // geting the data from api
        $response = $client->request('GET', 'https://api.dhl.com/location-finder/v1/find-by-address', [
        'headers' => [
            'DHL-API-Key' => 'demo-key',
        ],
        'query' => [
            'countryCode' => $country_code ? trim($country_code) : '',
            'cityName' => $city ? trim($city) : '',
            'postalCode' => $postal_code ? trim($postal_code) : '',
        ],
        ]);
        $data = json_decode($response->getBody(), TRUE);
            $new_array = [];
            $filteredData = [];
            if(is_array($data) && isset($data['locations']) && !empty($data['locations']))
            {
            foreach($data['locations'] as $k => $v)
            {
                $new_array[$k]['locationName']= $v['name'] ?? '';
                $new_array[$k]['address']['countryCode']= $v['place']['address']['countryCode'] ?? '';
                $new_array[$k]['address']['postalCode']= $v['place']['address']['postalCode'] ?? '';
                $new_array[$k]['address']['addressLocality']= $v['place']['address']['addressLocality'] ?? '';
                $new_array[$k]['address']['streetAddress']= $v['place']['address']['streetAddress'] ?? '';
                if(isset($v['openingHours'])){
                foreach($v['openingHours'] as $k1 => $v1)
                {
                $dayName = $this->getStringLastVal($v1['dayOfWeek']);
                $new_array[$k]['openingHours'][$dayName] = $v1['opens'].' - '.$v1['closes'];
                }
                }   
            }

            $filteredData = array_filter($new_array, function($location) {
                $weekend_open = !empty($location['openingHours']['saturday']) || !empty($location['openingHours']['sunday']);
                $address = $location['address']['streetAddress'];        
                // Extract numbers from the address
                preg_match('/\d+/', $address, $matches);
                $address_number = isset($matches[0]) ? (int) $matches[0] : 0;        
                // Filter out odd numbered addresses
                return $weekend_open && ($address_number % 2 == 0);
            });
            }
        return array_values($filteredData) ?? [];
        }else{
            return [];
        }

    } catch (ClientException $e) {
        if ($e->hasResponse()) {
            $response = $e->getResponse();
            $responseBody = $response->getBody()->getContents();
            $responseData = json_decode($responseBody, true);
            return $responseData['detail'];
        } else {
            return ['An unexpected error occurred'];
        }
    } catch (\Exception $e) {
        return ['An unexpected error occurred'];
    }
    }

    public function getStringLastVal(string $srting)
    {
        if($srting)
        {
            $string = explode("/", $srting);
            return strtolower(end($string));
        }
        else{
            return '';
        }
    }
}


