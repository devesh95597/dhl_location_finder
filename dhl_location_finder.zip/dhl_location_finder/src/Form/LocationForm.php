<?php
namespace Drupal\dhl_location_finder\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;


class LocationForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'dhl_location_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
  
    $country_code = \Drupal::request()->get('countryCode');
    $city = \Drupal::request()->get('addressLocality');
    $postal_code = \Drupal::request()->get('postalCode');
    $form['country_code'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Country Code'),
      '#required' => TRUE,
      '#default_value' => $country_code ?? '',
    ];

    $form['city'] = [
      '#type' => 'textfield',
      '#title' => $this->t('City'),
      '#default_value' => $city ?? '',
    ];

    $form['postal_code'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Postal Code'),
      '#default_value' => $postal_code ?? '',
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Search'),
    ];

    return $form;
  }
 /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state)
  {
    $country_code = trim($form_state->getValue('country_code'));
    $city = trim($form_state->getValue('city'));
    $postal_code = trim($form_state->getValue('postal_code'));
    if (!preg_match('/^[a-zA-Z]+$/', $country_code)) {
      $form_state->setErrorByName('country_code', $this->t('The County Code should only contain letters.'));
    }
    if(!empty($city )){
      if (!preg_match('/^[a-zA-Z]+$/', $city)) {
        $form_state->setErrorByName('city', $this->t('The City Code should only contain letters.'));
      }
    }
    if(!empty($postal_code )){
      if (!preg_match('/^[a-zA-Z0-9]+$/', $postal_code)) {
        $form_state->setErrorByName('postal_code', $this->t('The Postal Code should only contain Number.'));
      }
    }
  }
  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $country_code = trim($form_state->getValue('country_code'));
    $city = trim($form_state->getValue('city'));
    $postal_code = trim($form_state->getValue('postal_code'));
    $form_state->setRedirect('dhl_location_finder.search', [], ['query' => ['countryCode' => $country_code,'addressLocality' => $city, 'postalCode' => $postal_code]]);
  }

}