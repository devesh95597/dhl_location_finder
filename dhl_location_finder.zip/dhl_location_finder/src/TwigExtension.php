<?php

namespace Drupal\dhl_location_finder;

use Twig\Extension\AbstractExtension;
use Twig\TwigFilter;
/**
 * Class DefaultService.
 *
 * @package Drupal\dhl_location_finder
 */
class TwigExtension extends AbstractExtension {

  /**
   * In this function we can declare the TwigFilter function.
   */
  public function getFilters() {
    return array(
      new TwigFilter('to_yaml', [$this, 'toYaml']),
    );
  }

  public function toYaml($string) {
    return str_replace(' ', '&nbsp;', $string);
  }
  

}